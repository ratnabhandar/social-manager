package com.socialmanager.app

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SERIES_COLORS = listOf(
    Color(0xFFE1306C), Color(0xFF1877F2), Color(0xFFFF0000), Color(0xFF00A67E),
    Color(0xFFF5A623), Color(0xFF7B61FF), Color(0xFF00B8D9), Color(0xFF8D6E63),
)
private val DAYS = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

private fun fmt(n: Number) = NumberFormat.getIntegerInstance(Locale("en", "IN")).format(n)
private fun JSONArray.objects() = (0 until length()).map { getJSONObject(it) }

@Composable
fun ReportsScreen(url: String, apiKey: String, modifier: Modifier) {
    val scope = rememberCoroutineScope()
    var clients by remember { mutableStateOf<List<String>>(emptyList()) }
    var client by rememberSaveableString("")
    var days by remember { mutableIntStateOf(30) }
    var report by remember { mutableStateOf<JSONObject?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        if (url.isBlank()) { error = "Settings (⚙) mein Script URL daalein"; return }
        scope.launch {
            loading = true; error = null
            try {
                if (clients.isEmpty()) clients = Api.list(url, apiKey, "Clients").mapNotNull { it["Name"]?.takeIf(String::isNotBlank) }
                val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                val from = f.format(Date(System.currentTimeMillis() - (days - 1) * 86_400_000L))
                report = Api.get(url, apiKey, mapOf("action" to "report", "client" to client, "from" to from, "to" to today()))
            } catch (t: Throwable) {
                error = t.message ?: "Network error"
            }
            loading = false
        }
    }
    LaunchedEffect(client, days) { load() }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth()) else Spacer(Modifier.height(4.dp))

        Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DropdownField("Client", client.ifBlank { "Sab clients" }, listOf("Sab clients") + clients) {
                client = if (it == "Sab clients") "" else it
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(7, 30, 90).forEach { d ->
                    FilterChip(days == d, { days = d }, label = { Text("$d din") })
                }
            }
        }

        error?.let {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.padding(12.dp).fillMaxWidth(),
            ) { Text(it, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer) }
        }

        report?.let { ReportBody(it) }
    }
}

@Composable
private fun ReportBody(r: JSONObject) {
    Column {
        val followers = r.optJSONArray("followers")?.objects().orEmpty()
        val totals = r.optJSONObject("totals") ?: JSONObject()
        val posts = r.optJSONObject("posts") ?: JSONObject()

        // KPI tiles
        val tiles = buildList {
            followers.forEach { s ->
                val g = s.optInt("growth")
                add(s.optString("name") to "${fmt(s.optInt("latest"))}  (${if (g >= 0) "+" else ""}${fmt(g)})")
            }
            add("Likes" to fmt(totals.optLong("likes")))
            add("Comments" to fmt(totals.optLong("comments")))
            add("Reach" to fmt(totals.optLong("reach")))
            add("Posts published" to "${posts.optInt("posted")} / ${posts.optInt("planned")} planned")
            if (posts.optInt("failed") > 0) add("Failed posts" to posts.optInt("failed").toString())
        }
        SectionTitle("Overview")
        tiles.chunked(2).forEach { pair ->
            Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { (label, value) -> KpiTile(label, value, Modifier.weight(1f)) }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        SectionTitle("Followers growth")
        if (followers.none { (it.optJSONArray("points")?.length() ?: 0) > 1 }) {
            Hint("Graph ke liye kam se kam 2 din ka Stats data chahiye. Auto-stats roz raat 11 baje chalta hai.")
        } else {
            FollowerChart(followers)
        }

        SectionTitle("Best time to post")
        val bt = r.optJSONObject("bestTime")
        if (bt == null || bt.optInt("sample") == 0) {
            Hint("Posts ke stats aane ke baad yahan best time dikhega.")
        } else {
            BestTimeHeatmap(bt)
        }

        SectionTitle("Top posts")
        val top = r.optJSONArray("top")?.objects().orEmpty()
        if (top.isEmpty()) Hint("Is period mein koi post stats nahi.")
        top.forEach { TopPostCard(it) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun rememberSaveableString(initial: String): MutableState<String> =
    androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(initial) }

@Composable
private fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 6.dp))
}

@Composable
private fun Hint(t: String) {
    Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp))
}

@Composable
private fun KpiTile(label: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun FollowerChart(series: List<JSONObject>) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    // har series ko apne min-max par scale karte hain (alag platforms ke numbers bahut alag hote hain)
    val lines = series.map { s -> s.optString("name") to s.getJSONArray("points").objects().map { it.optDouble("value") } }
        .filter { it.second.size > 1 }
    Card(Modifier.padding(horizontal = 12.dp).fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Canvas(Modifier.fillMaxWidth().height(160.dp)) {
                for (i in 0..3) {
                    val y = size.height * i / 3f
                    drawLine(grid, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                }
                lines.forEachIndexed { idx, (_, vals) ->
                    val min = vals.min(); val max = vals.max()
                    val span = if (max - min < 1e-9) 1.0 else max - min
                    val path = Path()
                    vals.forEachIndexed { i, v ->
                        val x = size.width * i / (vals.size - 1)
                        val y = (size.height * (1 - (v - min) / span)).toFloat().coerceIn(4f, size.height - 4f)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, SERIES_COLORS[idx % SERIES_COLORS.size], style = Stroke(width = 5f))
                }
            }
            Spacer(Modifier.height(8.dp))
            lines.forEachIndexed { idx, (name, vals) ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                    Box(Modifier.size(10.dp).background(SERIES_COLORS[idx % SERIES_COLORS.size], CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Text("$name: ${fmt(vals.first().toLong())} → ${fmt(vals.last().toLong())}",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun BestTimeHeatmap(bt: JSONObject) {
    val rows = bt.getJSONArray("grid").let { g -> (0 until g.length()).map { d -> g.getJSONArray(d).let { r -> (0 until r.length()).map { r.optInt(it) } } } }
    val max = rows.flatten().maxOrNull()?.coerceAtLeast(1) ?: 1
    val base = MaterialTheme.colorScheme.primary
    val empty = MaterialTheme.colorScheme.surfaceVariant
    Card(Modifier.padding(horizontal = 12.dp).fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row {
                Spacer(Modifier.width(36.dp))
                (0 until 8).forEach { h ->
                    Text("%02d".format(h * 3), style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            rows.forEachIndexed { d, vals ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(DAYS[d], style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(36.dp))
                    vals.forEach { v ->
                        Box(
                            Modifier.weight(1f).height(22.dp).padding(1.5.dp)
                                .background(if (v == 0) empty else base.copy(alpha = 0.15f + 0.85f * v / max), RoundedCornerShape(4.dp))
                        )
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            val best = bt.optJSONArray("best")
            if (best != null && best.length() > 0) {
                Text("Sabse achha time:", style = MaterialTheme.typography.labelLarge)
                (0 until best.length()).forEach { i ->
                    Text("${i + 1}. ${best.optString(i)}", style = MaterialTheme.typography.bodySmall)
                }
            }
            Text("${bt.optInt("sample")} posts ke likes + comments + shares par based",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TopPostCard(p: JSONObject) {
    val ctx = LocalContext.current
    val link = p.optString("link")
    Card(
        Modifier.padding(horizontal = 12.dp, vertical = 4.dp).fillMaxWidth()
            .clickable(enabled = link.startsWith("http")) {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
            }
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(p.optString("caption").ifBlank { "(no caption)" }, maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium)
            val views = p.optInt("views")
            Text(
                listOfNotNull(
                    p.optString("platform"), p.optString("client"), p.optString("date"),
                    "♥ ${fmt(p.optInt("likes"))}", "💬 ${fmt(p.optInt("comments"))}",
                    if (views > 0) "▶ ${fmt(views)}" else null,
                ).filter { it.isNotBlank() }.joinToString(" · "),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
