package com.socialmanager.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("config", Context.MODE_PRIVATE)
        setContent { AppTheme { App(prefs) } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(prefs: SharedPreferences) {
    var url by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(url.isBlank()) }
    val byName = ENTITIES.associateBy { it.sheet }
    // bottom bar: Posts, Reports, Stats, Tasks, Clients  (null = Reports)
    val tabs: List<Entity?> = listOf(byName["Posts"], null, byName["Stats"], byName["Tasks"], byName["Clients"])
    val entity = tabs[tab]

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(entity?.title ?: "Reports", fontWeight = FontWeight.SemiBold) },
                actions = {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, e ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(e?.icon ?: Icons.Filled.Info, contentDescription = null) },
                        label = { Text(e?.title ?: "Reports", maxLines = 1) },
                    )
                }
            }
        },
    ) { pad ->
        key(tab, url, apiKey) {
            if (entity == null) ReportsScreen(url, apiKey, Modifier.padding(pad))
            else EntityScreen(entity, url, apiKey, Modifier.padding(pad))
        }
    }

    if (showSettings) {
        SettingsDialog(url, apiKey, onRun = { job -> Api.get(url, apiKey, mapOf("action" to "run", "job" to job)).optString("message") }, onDismiss = { if (url.isNotBlank()) showSettings = false }) { u, k ->
            url = u.trim(); apiKey = k.trim()
            prefs.edit().putString("url", url).putString("key", apiKey).apply()
            showSettings = false
        }
    }
}

@Composable
fun SettingsDialog(
    url: String, key: String, onRun: suspend (String) -> String,
    onDismiss: () -> Unit, onSave: (String, String) -> Unit,
) {
    var u by remember { mutableStateOf(url) }
    var k by remember { mutableStateOf(key) }
    var running by remember { mutableStateOf(false) }
    var runMsg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    fun run(job: String) = scope.launch {
        running = true; runMsg = null
        runMsg = try { onRun(job) } catch (t: Throwable) { "Error: ${t.message}" }
        running = false
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Google Sheet connect karein") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Apps Script ka Web app URL paste karein (…/exec par khatam hota hai).",
                    style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(u, { u = it }, label = { Text("Script URL") }, singleLine = true)
                OutlinedTextField(k, { k = it }, label = { Text("API key (optional)") }, singleLine = true)
                if (url.isNotBlank()) {
                    HorizontalDivider()
                    Text("Automatic jobs (Sheet apne aap bhi chalata hai)", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(enabled = !running, onClick = { run("publish") }) { Text("Publish check") }
                        OutlinedButton(enabled = !running, onClick = { run("stats") }) { Text("Stats lao") }
                    }
                    if (running) LinearProgressIndicator(Modifier.fillMaxWidth())
                    runMsg?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = u.trim().startsWith("https://"), onClick = { onSave(u, k) }) { Text("Save") }
        },
        dismissButton = { if (url.isNotBlank()) TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntityScreen(e: Entity, url: String, apiKey: String, modifier: Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<Row>>(emptyList()) }
    var clients by remember { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<Row?>(null) }
    var query by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    val needsClients = e.fields.any { it.fromClients }

    fun reload() {
        if (url.isBlank()) { error = "Settings (⚙) mein Script URL daalein"; return }
        scope.launch {
            loading = true; error = null
            try {
                rows = Api.list(url, apiKey, e.sheet)
                if (needsClients) clients = Api.list(url, apiKey, "Clients").mapNotNull { it["Name"]?.takeIf(String::isNotBlank) }
            } catch (t: Throwable) {
                error = t.message ?: "Network error"
            }
            loading = false
        }
    }

    fun send(action: String, row: Row, msg: String) {
        scope.launch {
            loading = true; error = null
            try {
                Api.send(url, apiKey, e.sheet, action, row)
                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                reload()
            } catch (t: Throwable) {
                error = t.message ?: "Save nahi hua"
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { reload() }

    val shown = remember(rows, query, statusFilter) {
        var list = rows
        if (query.isNotBlank()) list = list.filter { r -> r.values.any { it.contains(query, ignoreCase = true) } }
        if (statusFilter != null && e.statusKey != null) list = list.filter { it[e.statusKey!!] == statusFilter }
        if (e.dateKey != null) {
            list = list.sortedBy { it[e.dateKey].orEmpty().ifBlank { "9999" } + (it["Time"] ?: "") }
            if (!e.dateAscending) list = list.reversed()
        }
        list
    }

    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth()) else Spacer(Modifier.height(4.dp))
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Search ${e.title.lowercase()}…") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    singleLine = true, modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { reload() }) { Icon(Icons.Filled.Refresh, "Refresh") }
            }
            val statusOptions = e.fields.firstOrNull { it.key == e.statusKey }?.options
            if (statusOptions != null) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item {
                        FilterChip(statusFilter == null, { statusFilter = null }, label = { Text("All (${rows.size})") })
                    }
                    items(statusOptions) { s ->
                        val n = rows.count { it[e.statusKey!!] == s }
                        FilterChip(statusFilter == s, { statusFilter = if (statusFilter == s) null else s },
                            label = { Text("$s ($n)") })
                    }
                }
            }
            error?.let {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                ) { Text(it, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer) }
            }
            if (!loading && error == null && shown.isEmpty()) {
                Text(
                    if (rows.isEmpty()) "Abhi koi entry nahi. + dabakar pehli entry add karein."
                    else "Is filter mein kuch nahi mila.",
                    Modifier.padding(24.dp), style = MaterialTheme.typography.bodyMedium,
                )
            }
            LazyColumn(
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                var lastDate: String? = null
                shown.forEach { row ->
                    val d = e.dateKey?.let { row[it].orEmpty() }
                    if (d != null && e.dateAscending && d != lastDate) {
                        lastDate = d
                        item(key = "h-$d-${row["ID"]}") {
                            Text(
                                when {
                                    d.isBlank() -> "Bina date"
                                    d == today() -> "Aaj · $d"
                                    d < today() -> "$d (beet gaya)"
                                    else -> d
                                },
                                style = MaterialTheme.typography.labelLarge,
                                color = if (d == today()) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 10.dp, start = 4.dp),
                            )
                        }
                    }
                    item(key = row["ID"] ?: row.hashCode().toString()) {
                        RowCard(e, row, onClick = { editing = row }, onAdvanceStatus = { next ->
                            send("update", row + (e.statusKey!! to next), "Status: $next")
                        })
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { editing = emptyMap() },
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text("Add") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        )
    }

    editing?.let { current ->
        val isNew = current.isEmpty()
        val del: (() -> Unit)? = if (isNew) null else {
            { editing = null; send("delete", current, "Delete ho gaya") }
        }
        EditDialog(
            e = e, initial = current, clients = clients,
            onDismiss = { editing = null },
            onSave = { r ->
                editing = null
                if (isNew) send("add", r + ("ID" to UUID.randomUUID().toString().take(8)), "Sheet mein save ho gaya")
                else send("update", r, "Update ho gaya")
            },
            onDelete = del,
        )
    }
}

@Composable
fun RowCard(e: Entity, row: Row, onClick: () -> Unit, onAdvanceStatus: (String) -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    row[e.titleKey].orEmpty().ifBlank { "(khaali)" },
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                val opts = e.fields.firstOrNull { it.key == e.statusKey }?.options
                if (e.statusKey != null && opts != null) {
                    val cycle = opts.filter { it != "Failed" }
                    val cur = row[e.statusKey].orEmpty().ifBlank { cycle.first() }
                    val next = cycle[(cycle.indexOf(cur) + 1).mod(cycle.size)]
                    AssistChip(onClick = { onAdvanceStatus(next) }, label = { Text(cur) })
                }
            }
            val sub = e.subtitleKeys.mapNotNull { k ->
                row[k]?.takeIf { it.isNotBlank() }?.let { v -> if (e.sheet == "Stats") "$k: $v" else v }
            }
            if (sub.isNotEmpty()) {
                Text(sub.joinToString(" · "), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val result = e.resultKey?.let { row[it] }.orEmpty()
            if (result.isNotBlank()) {
                Text(result, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis,
                    color = if (result.startsWith("ERROR")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
            if (!e.dateAscending && e.dateKey != null) {
                Text(row[e.dateKey].orEmpty(), style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun EditDialog(
    e: Entity, initial: Row, clients: List<String>,
    onDismiss: () -> Unit, onSave: (Row) -> Unit, onDelete: (() -> Unit)?,
) {
    val values = remember {
        mutableStateMapOf<String, String>().apply {
            putAll(initial)
            if (initial.isEmpty()) e.fields.forEach { f ->
                when {
                    f.kind == Kind.DATE && f.required -> put(f.key, today())
                    f.options != null -> put(f.key, f.options.first())
                }
            }
        }
    }
    var confirmDelete by remember { mutableStateOf(false) }
    val missing = e.fields.filter { it.required && values[it.key].isNullOrBlank() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.isEmpty()) "Naya ${e.title.removeSuffix("s")}" else "Edit") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                e.fields.forEach { f ->
                    if (f.readOnly) {
                        val v = values[f.key].orEmpty()
                        if (v.isNotBlank()) Text("${f.label.substringBefore(" (")}: $v", style = MaterialTheme.typography.bodySmall)
                    } else {
                    val opts = if (f.fromClients) clients else f.options
                    val label = f.label + if (f.required) " *" else ""
                    if (opts != null && opts.isNotEmpty()) {
                        DropdownField(label, values[f.key].orEmpty(), opts) { values[f.key] = it }
                    } else {
                        OutlinedTextField(
                            value = values[f.key].orEmpty(),
                            onValueChange = { values[f.key] = it },
                            label = { Text(label) },
                            singleLine = f.kind != Kind.MULTILINE,
                            minLines = if (f.kind == Kind.MULTILINE) 3 else 1,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = when (f.kind) {
                                    Kind.NUMBER -> KeyboardType.Number
                                    else -> KeyboardType.Text
                                }
                            ),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    }
                }
                if (onDelete != null) {
                    TextButton(onClick = { if (confirmDelete) onDelete() else confirmDelete = true }) {
                        Text(if (confirmDelete) "Pakka delete karein?" else "Delete",
                            color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = missing.isEmpty(), onClick = { onSave(values.toMap()) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DropdownField(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = value, onValueChange = onChange,
            label = { Text(label) }, singleLine = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { o ->
                DropdownMenuItem(text = { Text(o) }, onClick = { onChange(o); expanded = false })
            }
        }
    }
}
