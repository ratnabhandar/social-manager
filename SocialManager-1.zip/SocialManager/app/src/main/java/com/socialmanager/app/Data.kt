package com.socialmanager.app

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

typealias Row = Map<String, String>

enum class Kind { TEXT, MULTILINE, NUMBER, DATE, TIME }

data class Field(
    val key: String,
    val label: String,
    val kind: Kind = Kind.TEXT,
    val options: List<String>? = null,
    val fromClients: Boolean = false,
    val required: Boolean = false,
    val readOnly: Boolean = false,
)

data class Entity(
    val sheet: String,
    val title: String,
    val icon: ImageVector,
    val fields: List<Field>,
    val titleKey: String,
    val subtitleKeys: List<String>,
    val statusKey: String? = null,
    val dateKey: String? = null,
    val dateAscending: Boolean = false,
    val resultKey: String? = null,
)

val PLATFORMS = listOf("Instagram", "Facebook", "YouTube", "X (Twitter)", "LinkedIn", "WhatsApp", "Threads", "Pinterest")
val AUTO_PLATFORMS = listOf("Instagram", "Facebook", "Instagram + Facebook", "YouTube")
val POST_PLATFORMS = AUTO_PLATFORMS + listOf("X (Twitter)", "LinkedIn", "WhatsApp", "Threads", "Pinterest")
val POST_STATUS = listOf("Draft", "Approved", "Scheduled", "Posted", "Failed")
val MEDIA_TYPES = listOf("Image", "Reel", "Video", "Text")
val TASK_STATUS = listOf("To Do", "In Progress", "Review", "Done")

val ENTITIES = listOf(
    Entity(
        sheet = "Posts", title = "Posts", icon = Icons.Filled.DateRange,
        fields = listOf(
            Field("Client", "Client", fromClients = true, required = true),
            Field("Platform", "Platform", options = POST_PLATFORMS, required = true),
            Field("Caption", "Caption", Kind.MULTILINE, required = true),
            Field("Media Type", "Media type", options = MEDIA_TYPES),
            Field("Media URL", "Media URL (Google Drive link ya direct link)"),
            Field("Date", "Date (YYYY-MM-DD)", Kind.DATE, required = true),
            Field("Time", "Time (HH:MM, 24 ghante)", Kind.TIME),
            Field("Auto Publish", "Auto publish", options = listOf("Yes", "No")),
            Field("Status", "Status (Scheduled = auto post hoga)", options = POST_STATUS),
            Field("Result", "Result (script bharega)", readOnly = true),
        ),
        titleKey = "Caption", subtitleKeys = listOf("Client", "Platform", "Media Type", "Time"),
        resultKey = "Result",
        statusKey = "Status", dateKey = "Date", dateAscending = true,
    ),
    Entity(
        sheet = "Clients", title = "Clients", icon = Icons.Filled.Person,
        fields = listOf(
            Field("Name", "Client / Brand name", required = true),
            Field("Platforms", "Platforms (comma se alag)"),
            Field("Handle", "Handle / Page link"),
            Field("Contact", "Phone / Email"),
            Field("Notes", "Notes", Kind.MULTILINE),
            Field("FB Page ID", "Facebook Page ID"),
            Field("IG User ID", "Instagram User ID"),
            Field("YouTube Channel ID", "YouTube Channel ID (UC…)"),
            Field("Page Token", "Meta Page Token"),
        ),
        titleKey = "Name", subtitleKeys = listOf("Platforms", "Handle", "Contact"),
    ),
    Entity(
        sheet = "Stats", title = "Stats", icon = Icons.Filled.Star,
        fields = listOf(
            Field("Date", "Date (YYYY-MM-DD)", Kind.DATE, required = true),
            Field("Client", "Client", fromClients = true, required = true),
            Field("Platform", "Platform", options = PLATFORMS, required = true),
            Field("Followers", "Followers", Kind.NUMBER),
            Field("Likes", "Likes", Kind.NUMBER),
            Field("Comments", "Comments", Kind.NUMBER),
            Field("Reach", "Reach", Kind.NUMBER),
            Field("Views", "Views", Kind.NUMBER),
        ),
        titleKey = "Client", subtitleKeys = listOf("Platform", "Followers", "Likes", "Comments", "Reach", "Views", "Source"),
        dateKey = "Date",
    ),
    Entity(
        sheet = "Tasks", title = "Tasks", icon = Icons.Filled.CheckCircle,
        fields = listOf(
            Field("Title", "Task", required = true),
            Field("Client", "Client", fromClients = true),
            Field("Assignee", "Kisko diya"),
            Field("Due", "Due date (YYYY-MM-DD)", Kind.DATE),
            Field("Status", "Status", options = TASK_STATUS),
            Field("Notes", "Notes", Kind.MULTILINE),
        ),
        titleKey = "Title", subtitleKeys = listOf("Client", "Assignee", "Due"),
        statusKey = "Status", dateKey = "Due", dateAscending = true,
    ),
)

/** Apps Script web app se baat karta hai. */
object Api {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    suspend fun list(url: String, key: String, sheet: String): List<Row> = withContext(Dispatchers.IO) {
        val conn = URL("$url?sheet=${enc(sheet)}&key=${enc(key)}").openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        val json = read(conn)
        val arr = json.getJSONArray("rows")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            o.keys().asSequence().associateWith { o.optString(it) }
        }
    }

    suspend fun get(url: String, key: String, params: Map<String, String>): JSONObject = withContext(Dispatchers.IO) {
        val q = (params + ("key" to key)).entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
        val conn = URL("$url?$q").openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20000
        conn.readTimeout = 300000   // publish/stats jobs mein time lag sakta hai
        read(conn)
    }

    suspend fun send(url: String, key: String, sheet: String, action: String, row: Row) = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("key", key).put("sheet", sheet).put("action", action)
            .put("row", JSONObject(row))
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        read(conn)
        Unit
    }

    private fun read(conn: HttpURLConnection): JSONObject {
        try {
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw Exception("Server error $code")
            val json = try { JSONObject(text) } catch (e: Exception) {
                throw Exception("Sheet se sahi jawab nahi aaya. Script URL aur deployment access (Anyone) check karein.")
            }
            if (!json.optBoolean("ok")) throw Exception(json.optString("error", "Unknown error"))
            return json
        } finally {
            conn.disconnect()
        }
    }
}
