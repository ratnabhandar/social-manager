/**
 * Social Manager v2 — Google Sheet backend (Metricool-style)
 *
 * Kya karta hai:
 *  - App ke liye data API (doGet / doPost)
 *  - Auto-publish: har 10 min "Scheduled" posts ko Instagram / Facebook / YouTube par daalta hai
 *  - Auto-stats: roz raat followers, likes, comments, reach + har post ke stats Sheet mein
 *  - Reports + Best time to post: app ke Reports tab ke liye
 *
 * Setup ke steps README.md mein hain. Short mein:
 *  1. Project Settings → Time zone: (GMT+05:30) India  →  Services (+) → YouTube Data API v3 add karein
 *  2. setup() Run karein (sheets + triggers ban jayenge)
 *  3. Neeche META_* bharein → connectMeta() Run karein (Facebook pages + Instagram IDs + tokens Clients mein aa jayenge)
 *  4. Deploy → New deployment → Web app (Execute as: Me, Access: Anyone) → URL app mein daalein
 */

const API_KEY = '';           // optional: app ki Settings wali key
const GRAPH = 'https://graph.facebook.com/v25.0';

// connectMeta() ke liye (README: "Meta setup")
const META_APP_ID = '';
const META_APP_SECRET = '';
const META_USER_TOKEN = '';   // Graph API Explorer se mila User token

const SHEETS = {
  Clients:   ['ID', 'Name', 'Platforms', 'Handle', 'Contact', 'Notes', 'FB Page ID', 'IG User ID', 'YouTube Channel ID', 'Page Token', 'Updated At'],
  Posts:     ['ID', 'Client', 'Platform', 'Caption', 'Media URL', 'Media Type', 'Date', 'Time', 'Status', 'Auto Publish', 'Result', 'Updated At'],
  Stats:     ['ID', 'Date', 'Client', 'Platform', 'Followers', 'Likes', 'Comments', 'Reach', 'Views', 'Source', 'Updated At'],
  PostStats: ['ID', 'Client', 'Platform', 'Published At', 'Caption', 'Likes', 'Comments', 'Shares', 'Reach', 'Views', 'Link', 'Updated At'],
  Tasks:     ['ID', 'Title', 'Client', 'Assignee', 'Due', 'Status', 'Notes', 'Updated At'],
  Log:       ['Time', 'Job', 'Message'],
};
const MASK = '••••';

/* ───────────────────────── Setup ───────────────────────── */

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(SHEETS).forEach(function (name) {
    const sh = ss.getSheetByName(name) || ss.insertSheet(name);
    const headers = SHEETS[name];
    const lastCol = sh.getLastColumn();
    const old = lastCol ? sh.getRange(1, 1, 1, lastCol).getDisplayValues()[0] : [];
    if (old.join('|') !== headers.join('|')) {
      // purana data naye columns mein shift karo (v1 → v2 upgrade)
      const objs = readObjects(sh);
      sh.clearContents();
      sh.getRange(1, 1, 1, headers.length).setValues([headers]);
      if (objs.length) {
        sh.getRange(2, 1, objs.length, headers.length)
          .setValues(objs.map(function (o) { return headers.map(function (h) { return o[h] == null ? '' : o[h]; }); }));
      }
    }
    sh.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#e8eaf6');
    sh.setFrozenRows(1);
    sh.getRange('A:Z').setNumberFormat('@');
  });
  const def = ss.getSheetByName('Sheet1');
  if (def && def.getLastRow() === 0) ss.deleteSheet(def);

  ScriptApp.getProjectTriggers().forEach(function (t) { ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('publishDue').timeBased().everyMinutes(10).create();
  ScriptApp.newTrigger('collectStats').timeBased().everyDays(1).atHour(23).create();
  log('setup', 'Sheets + triggers ready');
}

/* ───────────────────────── Web API ───────────────────────── */

function doGet(e) {
  try {
    const p = e.parameter;
    checkKey(p.key);
    if (p.action === 'report') return out(Object.assign({ ok: true }, buildReport(p.client || '', p.from, p.to)));
    if (p.action === 'run') {
      if (p.job === 'publish') return out({ ok: true, message: publishDue() });
      if (p.job === 'stats') return out({ ok: true, message: collectStats() });
      throw new Error('Unknown job');
    }
    const rows = readObjects(getSheet(p.sheet));
    if (p.sheet === 'Clients') rows.forEach(function (r) {
      if (r['Page Token']) r['Page Token'] = MASK + r['Page Token'].slice(-4);
    });
    return out({ ok: true, rows: rows });
  } catch (err) {
    return out({ ok: false, error: String(err.message || err) });
  }
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const body = JSON.parse(e.postData.contents);
    checkKey(body.key);
    const sh = getSheet(body.sheet);
    const headers = SHEETS[body.sheet];
    const row = body.row || {};
    const idx = findRow(sh, row.ID);

    if (body.action === 'delete') {
      if (idx < 0) throw new Error('ID nahi mila: ' + row.ID);
      sh.deleteRow(idx);
      return out({ ok: true });
    }
    if (body.sheet === 'Clients' && String(row['Page Token'] || '').indexOf(MASK) === 0) {
      // masked token wapas aaya → purana token hi rakho
      row['Page Token'] = idx > 0 ? sh.getRange(idx, headers.indexOf('Page Token') + 1).getValue() : '';
    }
    row['Updated At'] = now();
    const line = headers.map(function (h) { return row[h] == null ? '' : String(row[h]); });
    if (body.action === 'add') sh.appendRow(line);
    else if (body.action === 'update') {
      if (idx < 0) throw new Error('ID nahi mila: ' + row.ID);
      sh.getRange(idx, 1, 1, line.length).setValues([line]);
    } else throw new Error('Galat action: ' + body.action);
    return out({ ok: true });
  } catch (err) {
    return out({ ok: false, error: String(err.message || err) });
  } finally {
    lock.releaseLock();
  }
}

/* ───────────────────────── Auto-publish ───────────────────────── */

function publishDue() {
  // dobara-publish se bachne ke liye: ek waqt mein ek hi publish run
  const cache = CacheService.getScriptCache();
  if (cache.get('publishing')) return 'Publish pehle se chal raha hai';
  cache.put('publishing', '1', 360);
  try { return publishDueInner(); } finally { cache.remove('publishing'); }
}

function publishDueInner() {
  const tz = Session.getScriptTimeZone();
  const sh = getSheet('Posts');
  const headers = SHEETS.Posts;
  const clients = clientMap();
  const values = sh.getDataRange().getDisplayValues();
  const col = function (h) { return headers.indexOf(h); };
  let done = 0, failed = 0;

  for (let i = 1; i < values.length; i++) {
    const r = values[i];
    if (r[col('Status')] !== 'Scheduled' || r[col('Auto Publish')] === 'No') continue;
    const when = Utilities.parseDate(r[col('Date')] + ' ' + (r[col('Time')] || '09:00'), tz, 'yyyy-MM-dd HH:mm');
    if (when.getTime() > Date.now()) continue;

    const rowNum = i + 1;
    sh.getRange(rowNum, col('Status') + 1).setValue('Publishing');
    SpreadsheetApp.flush();
    const post = {};
    headers.forEach(function (h, j) { post[h] = r[j]; });
    let status, result;
    try {
      const client = clients[post.Client];
      if (!client) throw new Error('Client "' + post.Client + '" Clients sheet mein nahi mila');
      result = publishPost(post, client).join(' | ');
      status = 'Posted'; done++;
    } catch (err) {
      result = 'ERROR: ' + (err.message || err);
      status = 'Failed'; failed++;
    }
    sh.getRange(rowNum, col('Status') + 1).setValue(status);
    sh.getRange(rowNum, col('Result') + 1).setValue(result);
    sh.getRange(rowNum, col('Updated At') + 1).setValue(now());
    log('publish', post.Client + ' / ' + post.Platform + ': ' + status + ' — ' + result);
  }
  return 'Published: ' + done + ', Failed: ' + failed;
}

function publishPost(post, client) {
  const p = post.Platform;
  const out = [];
  if (p === 'Instagram' || p === 'Instagram + Facebook') out.push('IG: ' + publishInstagram(post, client));
  if (p === 'Facebook' || p === 'Instagram + Facebook') out.push('FB: ' + publishFacebook(post, client));
  if (p === 'YouTube') out.push('YT: ' + publishYouTube(post, client));
  if (!out.length) throw new Error(p + ' ke liye auto-publish nahi hai — manual post karein');
  return out;
}

function publishInstagram(post, c) {
  if (!c['IG User ID'] || !c['Page Token']) throw new Error('Client mein IG User ID / Page Token nahi');
  const type = post['Media Type'] || 'Image';
  if (type === 'Text' || !post['Media URL']) throw new Error('Instagram ke liye image/video URL zaroori hai');
  const url = publicMediaUrl(post['Media URL']);
  const params = { caption: post.Caption, access_token: c['Page Token'] };
  if (type === 'Image') params.image_url = url;
  else { params.media_type = 'REELS'; params.video_url = url; }

  const container = graph('/' + c['IG User ID'] + '/media', params, 'post').id;
  if (type !== 'Image') waitForContainer(container, c['Page Token']);
  const id = graph('/' + c['IG User ID'] + '/media_publish', { creation_id: container, access_token: c['Page Token'] }, 'post').id;
  try { return graph('/' + id, { fields: 'permalink', access_token: c['Page Token'] }).permalink || id; }
  catch (e) { return id; }
}

function waitForContainer(id, token) {
  for (let i = 0; i < 24; i++) {
    const s = graph('/' + id, { fields: 'status_code,status', access_token: token });
    if (s.status_code === 'FINISHED') return;
    if (s.status_code === 'ERROR' || s.status_code === 'EXPIRED') throw new Error('Video process nahi hua: ' + (s.status || s.status_code));
    Utilities.sleep(10000);
  }
  throw new Error('Video processing mein zyada time laga — dobara Scheduled karke try karein');
}

function publishFacebook(post, c) {
  if (!c['FB Page ID'] || !c['Page Token']) throw new Error('Client mein FB Page ID / Page Token nahi');
  const page = c['FB Page ID'], token = c['Page Token'];
  const type = post['Media Type'] || 'Image';
  let res;
  if (type === 'Text' || !post['Media URL']) {
    res = graph('/' + page + '/feed', { message: post.Caption, access_token: token }, 'post');
  } else if (type === 'Image') {
    res = graph('/' + page + '/photos', { url: publicMediaUrl(post['Media URL']), message: post.Caption, access_token: token }, 'post');
  } else {
    res = graph('/' + page + '/videos', { file_url: publicMediaUrl(post['Media URL']), description: post.Caption, access_token: token }, 'post');
  }
  return 'https://facebook.com/' + (res.post_id || res.id);
}

function publishYouTube(post, c) {
  if (typeof YouTube === 'undefined') throw new Error('Apps Script mein Services → YouTube Data API v3 add karein');
  const fileId = driveId(post['Media URL']);
  if (!fileId) throw new Error('YouTube ke liye Google Drive video link chahiye');
  const mine = YouTube.Channels.list('id', { mine: true }).items || [];
  if (c['YouTube Channel ID'] && !mine.some(function (ch) { return ch.id === c['YouTube Channel ID']; })) {
    throw new Error('Upload sirf us channel par ho sakta hai jis Google account se script chal rahi hai');
  }
  const caption = String(post.Caption || '');
  const title = (caption.split('\n')[0] || 'Video').slice(0, 100);
  const blob = DriveApp.getFileById(fileId).getBlob();
  const v = YouTube.Videos.insert(
    { snippet: { title: title, description: caption }, status: { privacyStatus: 'public' } },
    'snippet,status', blob);
  return 'https://youtu.be/' + v.id;
}

/* ───────────────────────── Auto-stats ───────────────────────── */

function collectStats() {
  const date = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
  const clients = clientMap();
  const msgs = [];
  Object.keys(clients).forEach(function (name) {
    const c = clients[name];
    [['Instagram', c['IG User ID'] && c['Page Token'], igStats],
     ['Facebook', c['FB Page ID'] && c['Page Token'], fbStats],
     ['YouTube', c['YouTube Channel ID'], ytStats]].forEach(function (job) {
      if (!job[1]) return;
      try {
        const s = job[2](c);
        upsert('Stats', {
          ID: 'auto-' + date + '-' + name + '-' + job[0], Date: date, Client: name, Platform: job[0],
          Followers: s.followers, Likes: s.likes, Comments: s.comments, Reach: s.reach, Views: s.views, Source: 'Auto',
        });
        (s.posts || []).forEach(function (p) {
          p.Client = name; p.Platform = job[0];
          upsert('PostStats', p);
        });
        msgs.push(name + '/' + job[0] + ' ✓');
      } catch (err) {
        msgs.push(name + '/' + job[0] + ' ✗ ' + (err.message || err));
      }
    });
  });
  const m = msgs.join('\n') || 'Koi connected account nahi';
  log('stats', m);
  return m;
}

function igStats(c) {
  const t = c['Page Token'], ig = c['IG User ID'];
  const acc = graph('/' + ig, { fields: 'followers_count', access_token: t });
  const s = { followers: acc.followers_count, likes: '', comments: '', reach: '', views: '', posts: [] };
  try {
    const r = graph('/' + ig + '/insights', { metric: 'reach', period: 'day', access_token: t }).data[0].values;
    s.reach = r[r.length - 1].value;
  } catch (e) {}
  try {
    graph('/' + ig + '/insights', { metric: 'likes,comments,views', period: 'day', metric_type: 'total_value', access_token: t })
      .data.forEach(function (m) { s[m.name] = m.total_value.value; });
  } catch (e) {}
  const media = graph('/' + ig + '/media', {
    fields: 'id,caption,timestamp,like_count,comments_count,permalink', limit: 30, access_token: t }).data || [];
  media.forEach(function (m) {
    const p = { ID: 'ig_' + m.id, 'Published At': isoLocal(m.timestamp), Caption: short(m.caption),
      Likes: m.like_count || 0, Comments: m.comments_count || 0, Shares: '', Reach: '', Views: '', Link: m.permalink };
    try {
      graph('/' + m.id + '/insights', { metric: 'reach,views,shares', access_token: t }).data
        .forEach(function (x) { const v = x.values[0].value; if (x.name === 'reach') p.Reach = v; if (x.name === 'views') p.Views = v; if (x.name === 'shares') p.Shares = v; });
    } catch (e) {}
    s.posts.push(p);
  });
  return s;
}

function fbStats(c) {
  const t = c['Page Token'], page = c['FB Page ID'];
  const info = graph('/' + page, { fields: 'followers_count,fan_count', access_token: t });
  const s = { followers: info.followers_count || info.fan_count, likes: 0, comments: 0, reach: '', views: '', posts: [] };
  const today = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
  const posts = graph('/' + page + '/posts', {
    fields: 'id,message,created_time,permalink_url,shares,reactions.summary(total_count).limit(0),comments.summary(total_count).limit(0)',
    limit: 30, access_token: t }).data || [];
  posts.forEach(function (p) {
    const likes = (p.reactions && p.reactions.summary.total_count) || 0;
    const comments = (p.comments && p.comments.summary.total_count) || 0;
    const at = isoLocal(p.created_time);
    if (at.indexOf(today) === 0) { s.likes += likes; s.comments += comments; }
    s.posts.push({ ID: 'fb_' + p.id, 'Published At': at, Caption: short(p.message), Likes: likes,
      Comments: comments, Shares: (p.shares && p.shares.count) || 0, Reach: '', Views: '', Link: p.permalink_url });
  });
  return s;
}

function ytStats(c) {
  if (typeof YouTube === 'undefined') throw new Error('Services → YouTube Data API v3 add karein');
  const ch = (YouTube.Channels.list('statistics,contentDetails', { id: c['YouTube Channel ID'] }).items || [])[0];
  if (!ch) throw new Error('Channel ID galat hai');
  const s = { followers: ch.statistics.subscriberCount, likes: 0, comments: 0, reach: '', views: ch.statistics.viewCount, posts: [] };
  const uploads = ch.contentDetails.relatedPlaylists.uploads;
  const items = YouTube.PlaylistItems.list('contentDetails', { playlistId: uploads, maxResults: 25 }).items || [];
  if (!items.length) return s;
  const ids = items.map(function (i) { return i.contentDetails.videoId; }).join(',');
  (YouTube.Videos.list('snippet,statistics', { id: ids }).items || []).forEach(function (v) {
    s.posts.push({ ID: 'yt_' + v.id, 'Published At': isoLocal(v.snippet.publishedAt), Caption: short(v.snippet.title),
      Likes: v.statistics.likeCount || 0, Comments: v.statistics.commentCount || 0, Shares: '',
      Reach: '', Views: v.statistics.viewCount || 0, Link: 'https://youtu.be/' + v.id });
  });
  return s;
}

/* ───────────────────────── Reports + Best time ───────────────────────── */

function buildReport(client, from, to) {
  const tz = Session.getScriptTimeZone();
  to = to || Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd');
  from = from || Utilities.formatDate(new Date(Date.now() - 29 * 864e5), tz, 'yyyy-MM-dd');
  const inRange = function (d) { d = String(d).slice(0, 10); return d >= from && d <= to; };
  const mine = function (r) { return !client || r.Client === client; };
  const num = function (v) { const n = Number(String(v).replace(/,/g, '')); return isNaN(n) ? 0 : n; };

  const stats = readObjects(getSheet('Stats')).filter(function (r) { return mine(r) && inRange(r.Date); })
    .sort(function (a, b) { return a.Date < b.Date ? -1 : 1; });
  const series = {}, totals = { likes: 0, comments: 0, reach: 0 };
  stats.forEach(function (r) {
    const key = client ? r.Platform : r.Client + ' · ' + r.Platform;
    if (r.Followers !== '') {
      series[key] = series[key] || {};
      series[key][r.Date] = num(r.Followers);       // ek din mein last value
    }
    totals.likes += num(r.Likes); totals.comments += num(r.Comments); totals.reach += num(r.Reach);
  });
  const followers = Object.keys(series).map(function (k) {
    const pts = Object.keys(series[k]).sort().map(function (d) { return { date: d, value: series[k][d] }; });
    return { name: k, points: pts, growth: pts.length ? pts[pts.length - 1].value - pts[0].value : 0,
      latest: pts.length ? pts[pts.length - 1].value : 0 };
  });

  const posts = readObjects(getSheet('Posts')).filter(function (r) { return mine(r) && inRange(r.Date); });
  const postCounts = { planned: posts.length, posted: 0, scheduled: 0, failed: 0 };
  posts.forEach(function (p) {
    if (p.Status === 'Posted') postCounts.posted++;
    if (p.Status === 'Scheduled') postCounts.scheduled++;
    if (p.Status === 'Failed') postCounts.failed++;
  });

  const allPS = readObjects(getSheet('PostStats')).filter(mine);
  const eng = function (p) { return num(p.Likes) + num(p.Comments) + num(p.Shares); };
  const top = allPS.filter(function (p) { return inRange(p['Published At']); })
    .sort(function (a, b) { return eng(b) - eng(a); }).slice(0, 5)
    .map(function (p) { return { caption: p.Caption, platform: p.Platform, client: p.Client, date: String(p['Published At']).slice(0, 10),
      likes: num(p.Likes), comments: num(p.Comments), views: num(p.Views), link: p.Link }; });

  return { from: from, to: to, followers: followers, totals: totals, posts: postCounts, top: top, bestTime: bestTime(allPS, eng) };
}

/** 7 din × 8 slot (3-3 ghante) ka average engagement — saare purane posts se */
function bestTime(posts, eng) {
  const sum = [], cnt = [];
  for (let d = 0; d < 7; d++) { sum.push([0, 0, 0, 0, 0, 0, 0, 0]); cnt.push([0, 0, 0, 0, 0, 0, 0, 0]); }
  posts.forEach(function (p) {
    const m = String(p['Published At']).match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2})/);
    if (!m) return;
    const day = (new Date(+m[1], +m[2] - 1, +m[3]).getDay() + 6) % 7;  // Mon = 0
    const slot = Math.floor(+m[4] / 3);
    sum[day][slot] += eng(p); cnt[day][slot]++;
  });
  const grid = sum.map(function (row, d) { return row.map(function (s, h) { return cnt[d][h] ? Math.round(s / cnt[d][h]) : 0; }); });
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const slots = [];
  grid.forEach(function (row, d) { row.forEach(function (v, h) { if (cnt[d][h]) slots.push({ d: d, h: h, v: v, n: cnt[d][h] }); }); });
  slots.sort(function (a, b) { return b.v - a.v; });
  const pad = function (n) { return (n < 10 ? '0' : '') + n; };
  return {
    grid: grid,
    sample: posts.length,
    best: slots.slice(0, 3).map(function (s) {
      return days[s.d] + ' ' + pad(s.h * 3) + ':00–' + pad(s.h * 3 + 3) + ':00 (avg ' + s.v + ', ' + s.n + ' posts)';
    }),
  };
}

/* ───────────────────────── Meta connect helper ───────────────────────── */

/** META_USER_TOKEN se saare Facebook Pages + linked Instagram accounts Clients sheet mein bhar deta hai */
function connectMeta() {
  if (!META_USER_TOKEN) throw new Error('Pehle META_USER_TOKEN bharein');
  let token = META_USER_TOKEN;
  if (META_APP_ID && META_APP_SECRET) {
    token = graph('/oauth/access_token', { grant_type: 'fb_exchange_token', client_id: META_APP_ID,
      client_secret: META_APP_SECRET, fb_exchange_token: META_USER_TOKEN }).access_token;  // 60-day user token
  }
  const pages = graph('/me/accounts', { fields: 'id,name,access_token,instagram_business_account{id,username}', limit: 100, access_token: token }).data || [];
  const existing = readObjects(getSheet('Clients'));
  const lines = [];
  pages.forEach(function (pg) {
    const c = existing.filter(function (r) { return r['FB Page ID'] === pg.id || r.Name.toLowerCase() === pg.name.toLowerCase(); })[0] || {};
    const ig = pg.instagram_business_account;
    upsert('Clients', Object.assign({}, c, {
      ID: c.ID || ('meta_' + pg.id), Name: c.Name || pg.name,
      Platforms: c.Platforms || (ig ? 'Instagram, Facebook' : 'Facebook'),
      Handle: c.Handle || (ig ? '@' + ig.username : ''),
      'FB Page ID': pg.id, 'IG User ID': ig ? ig.id : '', 'Page Token': pg.access_token,
    }));
    lines.push(pg.name + (ig ? ' + IG @' + ig.username : ' (IG linked nahi)'));
  });
  log('connectMeta', lines.join('\n') || 'Koi page nahi mila — permissions check karein');
}

/* ───────────────────────── Helpers ───────────────────────── */

function graph(path, params, method) {
  const opts = { muteHttpExceptions: true, method: method || 'get' };
  let url = GRAPH + path;
  if (opts.method === 'get') {
    url += '?' + Object.keys(params).map(function (k) { return k + '=' + encodeURIComponent(params[k]); }).join('&');
  } else opts.payload = params;
  const res = JSON.parse(UrlFetchApp.fetch(url, opts).getContentText() || '{}');
  if (res.error) throw new Error(res.error.error_user_msg || res.error.message);
  return res;
}

function driveId(url) {
  const m = String(url || '').match(/\/d\/([\w-]{20,})|[?&]id=([\w-]{20,})/);
  return m ? (m[1] || m[2]) : null;
}

/** Google Drive link ko direct-download link bana deta hai (aur file ko public kar deta hai) */
function publicMediaUrl(url) {
  const id = driveId(url);
  if (!id) return url;
  try { DriveApp.getFileById(id).setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
  return 'https://drive.google.com/uc?export=download&id=' + id;
}

function clientMap() {
  const map = {};
  readObjects(getSheet('Clients')).forEach(function (c) { if (c.Name) map[c.Name] = c; });
  return map;
}

function readObjects(sh) {
  const v = sh.getDataRange().getDisplayValues();
  const headers = v.shift() || [];
  return v.filter(function (r) { return r[0] !== ''; }).map(function (r) {
    const o = {}; headers.forEach(function (h, i) { if (h) o[h] = r[i]; }); return o;
  });
}

function upsert(name, obj) {
  const sh = getSheet(name), headers = SHEETS[name];
  obj['Updated At'] = now();
  const line = headers.map(function (h) { return obj[h] == null ? '' : String(obj[h]); });
  const idx = findRow(sh, obj.ID);
  if (idx > 0) sh.getRange(idx, 1, 1, line.length).setValues([line]); else sh.appendRow(line);
}

function findRow(sh, id) {
  if (!id || sh.getLastRow() < 2) return -1;
  const ids = sh.getRange(1, 1, sh.getLastRow(), 1).getDisplayValues();
  for (let i = 1; i < ids.length; i++) if (ids[i][0] === String(id)) return i + 1;
  return -1;
}

function getSheet(name) {
  if (!SHEETS[name]) throw new Error('Unknown sheet: ' + name);
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" nahi mili — pehle setup() run karein');
  return sh;
}

function checkKey(k) { if (API_KEY && k !== API_KEY) throw new Error('API key galat hai'); }
function now() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm'); }
function isoLocal(s) {
  if (!s) return '';
  s = String(s).replace(/([+-]\d{2})(\d{2})$/, '$1:$2');   // Meta: +0000 → +00:00
  return Utilities.formatDate(new Date(s), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm');
}
function short(s) { s = String(s || '').replace(/\s+/g, ' '); return s.length > 120 ? s.slice(0, 117) + '…' : s; }

function log(job, msg) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Log');
  if (sh) sh.appendRow([now(), job, String(msg).slice(0, 5000)]);
}

function out(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
