# Social Manager v2 (Metricool-style) — Android + Google Sheet

**App (Kotlin):** Posts · Reports · Stats · Tasks · Clients
**Backend (Apps Script, free):**
- **Auto-publish** — har 10 min: jo post `Scheduled` hai aur time aa gaya, wo Instagram / Facebook / YouTube par chali jaati hai. Result (link ya error) Sheet + app mein dikhta hai.
- **Auto-stats** — roz raat 11 baje: followers, likes, comments, reach, views + har post ke stats (`PostStats` sheet).
- **Reports** — client-wise KPI, followers growth graph, top posts, **best time to post** heatmap.

---

## 1. Google Sheet + Apps Script
1. sheets.new par naya Sheet (ya purana v1 wala — data naye columns mein shift ho jayega).
2. **Extensions → Apps Script** → `apps-script/Code.gs` ka poora code paste → Save.
3. ⚙ **Project Settings** → Time zone: **(GMT+05:30) India Standard Time**.
4. Left mein **Services (+)** → **YouTube Data API v3** → Add. (YouTube nahi chahiye to skip.)
5. Function dropdown se **setup** → **Run** → permissions allow. Isse sheets aur dono automatic triggers ban jaate hain.
6. **Deploy → New deployment → Web app** → Execute as: **Me**, Access: **Anyone** → URL copy.
   Code badalne par: Deploy → Manage deployments → ✏ → Version: **New version** (URL wahi rahega).

## 2. Meta setup (Instagram + Facebook)
Shartein: Instagram account **Business ya Creator** ho aur ek **Facebook Page se linked** ho. Aap har client page ke admin hon.
1. developers.facebook.com → **Create App** → Business type; Instagram aur Facebook Pages wale use cases add karein.
2. **App Settings → Basic** se **App ID** aur **App Secret** copy karein.
3. **Tools → Graph API Explorer** → apni app chunein → **Get User Access Token** → ye permissions tick karein:
   `pages_show_list, pages_read_engagement, pages_manage_posts, read_insights, business_management, instagram_basic, instagram_content_publish, instagram_manage_insights`
   → Generate → token copy.
4. `Code.gs` mein upar `META_APP_ID`, `META_APP_SECRET`, `META_USER_TOKEN` bharein → Save → **connectMeta** Run karein.
   Saare pages + Instagram IDs + **non-expiring Page Token** `Clients` sheet mein aa jayenge (`Log` sheet mein list dikhegi).
5. App ko **Development mode** mein hi rehne dein — apne aur apne managed pages ke liye app review ki zaroorat nahi.

## 3. YouTube
- **Stats:** Clients mein `YouTube Channel ID` (UC… se shuru; youtube.com/account_advanced par milta hai) daalein — kisi bhi channel ke public stats aa jayenge.
- **Upload:** sirf us channel par jis Google account se script deploy hai. Video Google Drive par rakhein (≈50 MB tak), link `Media URL` mein.

## 4. APK banana
- **GitHub:** naya repo → saari files (`.github` folder ke saath) upload → **Actions** → "Build APK" → Artifacts se `SocialManager-apk` download.
- **Ya Android Studio:** folder Open → Build → Build APK(s).

App kholte hi Settings mein Web app URL daalein. Settings mein **Publish check** / **Stats lao** se jobs turant bhi chala sakte hain.

## Post kaise schedule karein
| Field | Kya daalein |
|---|---|
| Platform | Instagram, Facebook, **Instagram + Facebook**, YouTube (baaki platforms sirf planner ke liye) |
| Media type | Image, Reel, Video, Text (Text sirf Facebook) |
| Media URL | Google Drive share link (script khud public kar deta hai) ya koi direct link |
| Date / Time | 2026-10-20 / 18:30 (India time) |
| Status | **Scheduled** = time par auto post. Draft/Approved = kuch nahi hoga |

Dhyaan dein:
- Instagram images **JPEG** honi chahiye; Reels 3 sec – 15 min.
- Fail hone par Status `Failed` aur Result mein wajah aati hai — theek karke dobara `Scheduled` karein.
- Agar koi post `Publishing` par atki reh jaye, `Log` sheet dekhein, phir status khud badal dein.
- Followers graph ke liye kam se kam 2 din ka data chahiye; best-time jitne zyada posts, utna sahi.
